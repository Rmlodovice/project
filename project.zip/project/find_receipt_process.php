<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if email is set and not empty
    if (isset($_POST["email"]) && !empty($_POST["email"])) {
        // Sanitize and validate the email
        $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Here you can implement your logic to find the receipt associated with the provided email
            // For example, you might query a database to find the receipt data
            // Once you have the receipt data, you can display it or redirect the user to a receipt page
            // For demonstration purposes, let's assume we're just displaying a message

            echo "Receipt found for email: " . $email;
        } else {
            // Invalid email format
            echo "Invalid email format";
        }
    } else {
        // Email is not set or empty
        echo "Email is required";
    }
} else {
    // Redirect the user back to the find_receipt.php page if accessed directly without submitting the form
    header("Location: find_receipt.php");
    exit;
}
?>
